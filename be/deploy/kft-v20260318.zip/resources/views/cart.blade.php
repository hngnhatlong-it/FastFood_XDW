@extends('layouts.main')

@section('title', 'Giỏ hàng')

@section('content')
<h2 class="mb-4">Giỏ hàng của bạn</h2>

@if($cartItems->isEmpty())
    <div class="alert alert-info">
        Giỏ hàng trống. <a href="{{ route('home') }}">Tiếp tục mua sắm</a>
    </div>
@else
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                @php $total = 0; @endphp
                @foreach($cartItems as $item)
                    @php $subtotal = $item->product->price * $item->quantity; $total += $subtotal; @endphp
                    <tr>
                        <td>{{ $item->product->name }}</td>
                        <td>{{ number_format($item->product->price, 0, ',', '.') }} VNĐ</td>
                        <td>
                            <form action="{{ route('cart.update', $item->id) }}" method="POST" class="d-flex">
                                @csrf
                                @method('PUT')
                                <input type="number" name="quantity" value="{{ $item->quantity }}" min="1" class="form-control" style="width: 80px;">
                                <button type="submit" class="btn btn-sm btn-outline-primary ms-2">Cập nhật</button>
                            </form>
                        </td>
                        <td>{{ number_format($subtotal, 0, ',', '.') }} VNĐ</td>
                        <td>
                            <form action="{{ route('cart.remove', $item->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">Xóa</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" class="text-end">Tổng cộng:</th>
                    <th colspan="2">{{ number_format($total, 0, ',', '.') }} VNĐ</th>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h5>Thông tin đặt hàng</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('order.store') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label class="form-label">Địa chỉ giao hàng</label>
                    <input type="text" name="shipping_address" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Số điện thoại</label>
                    <input type="text" name="shipping_phone" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Ghi chú</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea>
                </div>
                <div class="alert alert-success">
                    <strong>Thanh toán:</strong> Thanh toán khi nhận hàng (COD)
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="bi bi-check-circle"></i> Đặt hàng ngay
                </button>
            </form>
        </div>
    </div>
@endif
@endsection
