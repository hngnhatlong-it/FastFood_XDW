@extends('layouts.main')

@section('title', 'KFT - Trang chủ')

@section('content')
<div class="hero-section mb-5 rounded">
    <div class="container">
        <h1>Chào mừng đến với KFT!</h1>
        <p>Đặt món ăn nhanh chóng và dễ dàng</p>
    </div>
</div>

<h2 class="section-title">Danh mục sản phẩm</h2>

@if($categories->isEmpty())
    <div class="alert alert-info">
        Chưa có danh mục nào. Admin vui lòng thêm danh mục!
    </div>
@else
    @foreach($categories as $category)
        <div class="mb-5">
            <h3 class="border-bottom pb-2 mb-3" style="color: var(--kft-black);">{{ $category->name }}</h3>
            @if($category->products->isEmpty())
                <p class="text-muted">Chưa có sản phẩm trong danh mục này.</p>
            @else
                <div id="carousel{{ $category->id }}" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        @foreach($category->products->chunk(4) as $index => $chunk)
                            <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                <div class="row">
                                    @foreach($chunk as $product)
                                        <div class="col-6 col-md-3 mb-3">
                                            <div class="card product-card h-100">
                                                @if($product->image)
                                                    <img src="{{ $product->image }}" class="card-img-top" alt="{{ $product->name }}">
                                                @else
                                                    <div class="text-center mb-3 mt-4">
                                                        <i class="bi bi-bucket" style="font-size: 3rem; color: var(--kft-red);"></i>
                                                    </div>
                                                @endif
                                                <div class="card-body p-2">
                                                    <h6 class="card-title">{{ $product->name }}</h6>
                                                    <p class="card-text text-muted small">{{ Str::limit($product->description, 40) }}</p>
                                                    <p class="price mb-1">{{ number_format($product->price, 0, ',', '.') }} VNĐ</p>
                                                    <div class="d-flex gap-1">
                                                        <a href="{{ route('product', $product->id) }}" class="btn btn-outline-secondary btn-sm">Chi tiết</a>
                                                        @auth
                                                            <form action="{{ route('cart.add') }}" method="POST">
                                                                @csrf
                                                                <input type="hidden" name="product_id" value="{{ $product->id }}">
                                                                <button type="submit" class="btn btn-kft btn-sm">
                                                                    <i class="bi bi-cart-plus"></i>
                                                                </button>
                                                            </form>
                                                        @else
                                                            <a href="{{ route('login') }}" class="btn btn-secondary btn-sm">Đăng nhập</a>
                                                        @endauth
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        @endforeach
                    </div>
                    @if($category->products->count() > 4)
                        <button class="carousel-control-prev" type="button" data-bs-target="#carousel{{ $category->id }}" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon bg-dark rounded-circle" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carousel{{ $category->id }}" data-bs-slide="next">
                            <span class="carousel-control-next-icon bg-dark rounded-circle" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    @endif
                </div>
            @endif
        </div>
    @endforeach
@endif
@endsection
