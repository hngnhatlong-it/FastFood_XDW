<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'KFT Vietnam')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --kft-red: #E4002B;
            --kft-dark-red: #C40024;
            --kft-white: #FFFFFF;
            --kft-black: #1A1A1A;
            --kft-gray: #F5F5F5;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #FAFAFA;
        }
        .navbar-brand { 
            font-weight: 900; 
            color: var(--kft-red) !important;
            font-size: 1.8rem;
            letter-spacing: 1px;
        }
        .navbar {
            background: var(--kft-white);
            border-bottom: 3px solid var(--kft-red);
            padding: 12px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        .navbar-light .navbar-nav .nav-link {
            color: var(--kft-black) !important;
            font-weight: 500;
            font-size: 0.95rem;
            padding: 8px 15px !important;
        }
        .navbar-light .navbar-nav .nav-link:hover {
            color: var(--kft-red) !important;
        }
        .btn-kft {
            background: var(--kft-red);
            border: none;
            color: white;
            font-weight: 600;
            padding: 10px 25px;
            border-radius: 4px;
        }
        .btn-kft:hover {
            background: var(--kft-dark-red);
            color: white;
        }
        .product-card { 
            transition: all 0.3s ease;
            border: 1px solid #eee;
            border-radius: 8px;
            overflow: hidden;
            background: white;
        }
        .product-card:hover { 
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-color: var(--kft-red);
        }
        .product-card .card-img-top {
            height: 200px;
            object-fit: cover;
            background: #f8f9fa;
        }
        .product-card .card-title {
            font-weight: 700;
            color: var(--kft-black);
            font-size: 1.1rem;
        }
        .product-card .price {
            color: var(--kft-red);
            font-weight: 700;
            font-size: 1.3rem;
        }
        .category-card {
            background: white;
            border: 2px solid var(--kft-red);
            border-radius: 10px;
            padding: 25px;
            text-align: center;
            color: var(--kft-red);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .category-card:hover {
            background: var(--kft-red);
            color: white;
            transform: scale(1.05);
        }
        .category-card i {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        .category-card h5 {
            font-weight: 700;
            font-size: 1rem;
        }
        .footer { 
            background: var(--kft-black); 
            color: #fff; 
            padding: 50px 0 30px; 
            margin-top: 50px;
        }
        .footer h5 {
            color: var(--kft-red);
            font-weight: 700;
        }
        .cart-badge {
            position: relative;
            display: inline-block;
        }
        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: var(--kft-red);
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 11px;
            font-weight: bold;
            min-width: 18px;
            text-align: center;
        }
        .hero-section {
            background: linear-gradient(135deg, var(--kft-red) 0%, var(--kft-dark-red) 100%);
            color: white;
            padding: 80px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 3.5rem;
            font-weight: 900;
            margin-bottom: 20px;
        }
        .hero-section p {
            font-size: 1.3rem;
            opacity: 0.95;
        }
        .section-title {
            color: var(--kft-black);
            font-weight: 700;
            margin-bottom: 30px;
            position: relative;
            display: inline-block;
            text-transform: uppercase;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: var(--kft-red);
        }
        .carousel-control-prev-icon, .carousel-control-next-icon {
            padding: 1.5rem;
            background-size: 50%;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="{{ route('home') }}">
                <i class="bi bi-bucket"></i> KFT
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('home') }}"><i class="bi bi-house"></i> Trang chủ</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    @auth
                        @php
                            $cartCount = \App\Models\CartItem::where('user_id', auth()->id())->sum('quantity');
                        @endphp
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('cart') }}">
                                <div class="cart-badge">
                                    <i class="bi bi-cart3"></i> Giỏ hàng
                                    @if($cartCount > 0)
                                        <span class="cart-count">{{ $cartCount }}</span>
                                    @endif
                                </div>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('orders') }}">Đơn hàng</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-circle"></i> {{ Auth::user()->name }}
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                @if(Auth::user()->isAdmin())
                                    <li><a class="dropdown-item" href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2"></i> Admin Panel</a></li>
                                @endif
                                <li><a class="dropdown-item" href="{{ route('profile.edit') }}"><i class="bi bi-person"></i> Hồ sơ</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="{{ route('logout') }}">
                                        @csrf
                                        <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right"></i> Đăng xuất</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}"><i class="bi bi-box-arrow-in-right"></i> Đăng nhập</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-kft btn-sm" href="{{ route('register') }}">Đăng ký</a>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4">
        <div class="container">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif
            @yield('content')
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5><i class="bi bi-bucket"></i> KFT</h5>
                    <p class="text-white">Thưởng thức gà giòn ngon nhất Việt Nam</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Liên kết nhanh</h5>
                    <ul class="list-unstyled">
                        <li><a href="{{ route('home') }}" class="text-decoration-none text-white">Trang chủ</a></li>
                        <li><a href="#" class="text-decoration-none text-white">Về chúng tôi</a></li>
                        <li><a href="#" class="text-decoration-none text-white">Liên hệ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Theo dõi chúng tôi</h5>
                    <div class="fs-4">
                        <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="text-white"><i class="bi bi-youtube"></i></a>
                    </div>
                </div>
            </div>
            <hr style="border-color: rgba(255,255,255,0.2);">
            <p class="text-center text-white mb-0">&copy; 2026 KFT Vietnam. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
