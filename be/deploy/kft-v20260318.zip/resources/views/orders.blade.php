@extends('layouts.main')

@section('title', 'Đơn hàng của tôi')

@section('content')
<h2 class="mb-4">Đơn hàng của tôi</h2>

@if($orders->isEmpty())
    <div class="alert alert-info">
        Bạn chưa có đơn hàng nào. <a href="{{ route('home') }}">Mua sắm ngay</a>
    </div>
@else
    @foreach($orders as $order)
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <strong>Đơn hàng #{{ $order->order_number }}</strong>
                    <small class="text-muted ms-2">{{ $order->created_at->format('d/m/Y H:i') }}</small>
                </div>
                <div>
                    @switch($order->status)
                        @case('pending')
                            <span class="badge bg-warning">Chờ xử lý</span>
                            @break
                        @case('processing')
                            <span class="badge bg-info">Đang xử lý</span>
                            @break
                        @case('completed')
                            <span class="badge bg-success">Hoàn thành</span>
                            @break
                        @case('cancelled')
                            <span class="badge bg-danger">Đã hủy</span>
                            @break
                    @endswitch
                </div>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($order->orderItems as $item)
                            <tr>
                                <td>{{ $item->product->name }}</td>
                                <td>{{ number_format($item->price, 0, ',', '.') }} VNĐ</td>
                                <td>{{ $item->quantity }}</td>
                                <td>{{ number_format($item->subtotal, 0, ',', '.') }} VNĐ</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="text-end">
                    <strong>Tổng cộng: {{ number_format($order->total_amount, 0, ',', '.') }} VNĐ</strong>
                </div>
                <div class="mt-2">
                    <strong>Địa chỉ giao:</strong> {{ $order->shipping_address }} - {{ $order->shipping_phone }}
                </div>
            </div>
        </div>
    @endforeach
@endif
@endsection
