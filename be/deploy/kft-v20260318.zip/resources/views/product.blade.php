@extends('layouts.main')

@section('title', $product->name)

@section('content')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('home') }}">Trang chủ</a></li>
        <li class="breadcrumb-item active">{{ $product->name }}</li>
    </ol>
</nav>

<div class="row">
    <div class="col-md-6">
        <div class="mb-4">
            @if($product->image)
                <img src="{{ $product->image }}" class="img-fluid rounded" alt="{{ $product->name }}" style="width: 100%; max-height: 400px; object-fit: cover;">
            @else
                <div class="text-center p-5 bg-light rounded">
                    <i class="bi bi-bucket" style="font-size: 8rem; color: var(--kft-red);"></i>
                </div>
            @endif
        </div>
    </div>
    <div class="col-md-6">
        <h1>{{ $product->name }}</h1>
        <p class="text-muted">Danh mục: {{ $product->category->name }}</p>
        <h2 class="price">{{ number_format($product->price, 0, ',', '.') }} VNĐ</h2>
        <p class="mt-3">{{ $product->description }}</p>
        
        @auth
            <form action="{{ route('cart.add') }}" method="POST" class="mt-4">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">
                <div class="row">
                    <div class="col-md-3">
                        <input type="number" name="quantity" value="1" min="1" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-kft w-100">
                            <i class="bi bi-cart-plus"></i> Thêm vào giỏ
                        </button>
                    </div>
                </div>
            </form>
        @else
            <div class="alert alert-warning mt-4">
                Vui lòng <a href="{{ route('login') }}">đăng nhập</a> để đặt hàng!
            </div>
        @endauth
        
        <a href="{{ route('home') }}" class="btn btn-outline-secondary mt-3">Quay lại</a>
    </div>
</div>
@endsection
