<?php $__env->startSection('title', 'Đơn hàng của tôi'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Đơn hàng của tôi</h2>

<?php if($orders->isEmpty()): ?>
    <div class="alert alert-info">
        Bạn chưa có đơn hàng nào. <a href="<?php echo e(route('home')); ?>">Mua sắm ngay</a>
    </div>
<?php else: ?>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <strong>Đơn hàng #<?php echo e($order->order_number); ?></strong>
                    <small class="text-muted ms-2"><?php echo e($order->created_at->format('d/m/Y H:i')); ?></small>
                </div>
                <div>
                    <?php switch($order->status):
                        case ('pending'): ?>
                            <span class="badge bg-warning">Chờ xử lý</span>
                            <?php break; ?>
                        <?php case ('processing'): ?>
                            <span class="badge bg-info">Đang xử lý</span>
                            <?php break; ?>
                        <?php case ('completed'): ?>
                            <span class="badge bg-success">Hoàn thành</span>
                            <?php break; ?>
                        <?php case ('cancelled'): ?>
                            <span class="badge bg-danger">Đã hủy</span>
                            <?php break; ?>
                    <?php endswitch; ?>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->name); ?></td>
                                <td><?php echo e(number_format($item->price, 0, ',', '.')); ?> VNĐ</td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td><?php echo e(number_format($item->subtotal, 0, ',', '.')); ?> VNĐ</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="text-end">
                    <strong>Tổng cộng: <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> VNĐ</strong>
                </div>
                <div class="mt-2">
                    <strong>Địa chỉ giao:</strong> <?php echo e($order->shipping_address); ?> - <?php echo e($order->shipping_phone); ?>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Code\PHP\fastfood_app\resources\views/orders.blade.php ENDPATH**/ ?>