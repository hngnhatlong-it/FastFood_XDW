<?php $__env->startSection('title', 'Quản lý sản phẩm'); ?>
<?php $__env->startSection('page-title', 'Quản lý sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="table-card mb-4">
    <div class="card-header">
        <i class="bi bi-plus-circle me-2"></i>Thêm sản phẩm mới
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.products.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-2">
                    <select name="category_id" class="form-select" required>
                        <option value="">Chọn danh mục</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="text" name="name" class="form-control" placeholder="Tên sản phẩm" required>
                </div>
                <div class="col-md-2">
                    <input type="number" name="price" class="form-control" placeholder="Giá (VNĐ)" required>
                </div>
                <div class="col-md-2">
                    <input type="text" name="image" class="form-control" placeholder="URL hình ảnh">
                </div>
                <div class="col-md-2">
                    <input type="text" name="description" class="form-control" placeholder="Mô tả">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-admin w-100">Thêm sản phẩm</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="table-card">
    <div class="card-header">
        <i class="bi bi-box-seam me-2"></i>Danh sách sản phẩm
    </div>
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Hình ảnh</th>
                    <th>Danh mục</th>
                    <th>Tên sản phẩm</th>
                    <th>Giá</th>
                    <th>Ngày tạo</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td>
                            <?php if($product->image): ?>
                                <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                            <?php else: ?>
                                <span class="text-muted">Chưa có ảnh</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge bg-warning text-dark"><?php echo e($product->category->name); ?></span></td>
                        <td><strong><?php echo e($product->name); ?></strong></td>
                        <td><span class="text-danger fw-bold"><?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ</span></td>
                        <td><?php echo e($product->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa sản phẩm này?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Code\PHP\fastfood_app\resources\views/admin/products.blade.php ENDPATH**/ ?>