<?php $__env->startSection('title', 'KFT - Trang chủ'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero-section mb-5 rounded">
    <div class="container">
        <h1>Chào mừng đến với KFT!</h1>
        <p>Đặt món ăn nhanh chóng và dễ dàng</p>
    </div>
</div>

<h2 class="section-title">Danh mục sản phẩm</h2>

<?php if($categories->isEmpty()): ?>
    <div class="alert alert-info">
        Chưa có danh mục nào. Admin vui lòng thêm danh mục!
    </div>
<?php else: ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-5">
            <h3 class="border-bottom pb-2 mb-3" style="color: var(--kft-black);"><?php echo e($category->name); ?></h3>
            <?php if($category->products->isEmpty()): ?>
                <p class="text-muted">Chưa có sản phẩm trong danh mục này.</p>
            <?php else: ?>
                <div id="carousel<?php echo e($category->id); ?>" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $category->products->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                <div class="row">
                                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-md-3 mb-3">
                                            <div class="card product-card h-100">
                                                <?php if($product->image): ?>
                                                    <img src="<?php echo e($product->image); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                                                <?php else: ?>
                                                    <div class="text-center mb-3 mt-4">
                                                        <i class="bi bi-bucket" style="font-size: 3rem; color: var(--kft-red);"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="card-body p-2">
                                                    <h6 class="card-title"><?php echo e($product->name); ?></h6>
                                                    <p class="card-text text-muted small"><?php echo e(Str::limit($product->description, 40)); ?></p>
                                                    <p class="price mb-1"><?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ</p>
                                                    <div class="d-flex gap-1">
                                                        <a href="<?php echo e(route('product', $product->id)); ?>" class="btn btn-outline-secondary btn-sm">Chi tiết</a>
                                                        <?php if(auth()->guard()->check()): ?>
                                                            <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                                <button type="submit" class="btn btn-kft btn-sm">
                                                                    <i class="bi bi-cart-plus"></i>
                                                                </button>
                                                            </form>
                                                        <?php else: ?>
                                                            <a href="<?php echo e(route('login')); ?>" class="btn btn-secondary btn-sm">Đăng nhập</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($category->products->count() > 4): ?>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carousel<?php echo e($category->id); ?>" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon bg-dark rounded-circle" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carousel<?php echo e($category->id); ?>" data-bs-slide="next">
                            <span class="carousel-control-next-icon bg-dark rounded-circle" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Code\PHP\fastfood_app\resources\views/home.blade.php ENDPATH**/ ?>