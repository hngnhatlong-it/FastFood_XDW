<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
        <li class="breadcrumb-item active"><?php echo e($product->name); ?></li>
    </ol>
</nav>

<div class="row">
    <div class="col-md-6">
        <div class="mb-4">
            <?php if($product->image): ?>
                <img src="<?php echo e($product->image); ?>" class="img-fluid rounded" alt="<?php echo e($product->name); ?>" style="width: 100%; max-height: 400px; object-fit: cover;">
            <?php else: ?>
                <div class="text-center p-5 bg-light rounded">
                    <i class="bi bi-bucket" style="font-size: 8rem; color: var(--kfc-red);"></i>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <h1><?php echo e($product->name); ?></h1>
        <p class="text-muted">Danh mục: <?php echo e($product->category->name); ?></p>
        <h2 class="price"><?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ</h2>
        <p class="mt-3"><?php echo e($product->description); ?></p>
        
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mt-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <div class="row">
                    <div class="col-md-3">
                        <input type="number" name="quantity" value="1" min="1" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-kfc w-100">
                            <i class="bi bi-cart-plus"></i> Thêm vào giỏ
                        </button>
                    </div>
                </div>
            </form>
        <?php else: ?>
            <div class="alert alert-warning mt-4">
                Vui lòng <a href="<?php echo e(route('login')); ?>">đăng nhập</a> để đặt hàng!
            </div>
        <?php endif; ?>
        
        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-secondary mt-3">Quay lại</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Code\PHP\fastfood_app\resources\views/product.blade.php ENDPATH**/ ?>