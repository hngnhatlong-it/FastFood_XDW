<?php $__env->startSection('title', 'Quản lý đơn hàng'); ?>
<?php $__env->startSection('page-title', 'Quản lý đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="table-card">
    <div class="card-header">
        <i class="bi bi-cart3 me-2"></i>Danh sách đơn hàng
    </div>
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Mã đơn</th>
                    <th>Khách hàng</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Thanh toán</th>
                    <th>Ngày đặt</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong>#<?php echo e($order->order_number); ?></strong></td>
                        <td>
                            <i class="bi bi-person me-1"></i><?php echo e($order->user->name); ?>

                            <br><small class="text-muted"><?php echo e($order->shipping_phone); ?></small>
                        </td>
                        <td><span class="text-danger fw-bold"><?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> VNĐ</span></td>
                        <td>
                            <form action="<?php echo e(route('admin.orders.update', $order->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <select name="status" class="form-select form-select-sm" style="width: auto;" onchange="this.form.submit()">
                                    <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Chờ xử lý</option>
                                    <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>Đang xử lý</option>
                                    <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Hoàn thành</option>
                                    <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Đã hủy</option>
                                </select>
                            </form>
                        </td>
                        <td>
                            <?php switch($order->payment_status):
                                case ('pending'): ?>
                                    <span class="status-badge pending">Chờ</span>
                                    <?php break; ?>
                                <?php case ('paid'): ?>
                                    <span class="status-badge completed">Đã thanh toán</span>
                                    <?php break; ?>
                                <?php case ('failed'): ?>
                                    <span class="status-badge cancelled">Thất bại</span>
                                    <?php break; ?>
                            <?php endswitch; ?>
                        </td>
                        <td><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                        <td>
                            <small class="text-muted"><?php echo e($order->shipping_address); ?></small>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Code\PHP\fastfood_app\resources\views/admin/orders.blade.php ENDPATH**/ ?>